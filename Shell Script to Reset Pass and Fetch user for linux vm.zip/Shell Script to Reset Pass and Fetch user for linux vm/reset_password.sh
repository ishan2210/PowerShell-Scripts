#!/bin/bash

# Prompt for the username and new password
read -p "Enter the username to reset the password: " ishan2210
read -p "Enter the new password: " -s Ishan52150
echo

# Check if the user exists
if id "ishan2210" &>/dev/null; then
    # Set the new password
    echo -e "Ishan52150\nIshan52150" | sudo passwd "ishan2210" &>/dev/null
    if [ $? -eq 0 ]; then
        echo "Password for user 'ishan2210' has been successfully reset."
    else
        echo "Failed to reset the password for user 'ishan2210'."
    fi
else
    echo "User 'ishan2210' does not exist."
fi
