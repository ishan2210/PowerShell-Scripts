#!/bin/bash

# Fetch all usernames from /etc/passwd
usernames=$(cut -d: -f1 /etc/passwd)

# Print the usernames
echo "List of all users:"
echo "$usernames"